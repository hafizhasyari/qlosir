# PRD — Qlosir (Aplikasi Kasir Warung Kelontong)

> Status: Draft v1 | Scope: MVP Full | Pemilik: 1 pemilik, 1 toko

## 1. Overview

Qlosir adalah **web app kasir mobile-first (PWA)** untuk warung kelontong, ditujukan untuk 1 pemilik dan 1 toko. Fokus utama: pencatatan transaksi cepat, manajemen & pantauan stok barang, serta pembuatan invoice yang bisa dicetak (printer thermal) maupun dikirim sebagai link digital ke WhatsApp pembeli.

Aplikasi diakses langsung dari HP pedagang agar cepat dan praktis, serta dapat di-install layaknya aplikasi native.

## 2. Persona & User

- **Pemilik Warung (Admin tunggal)** — satu-satunya pengguna. Bertanggung jawab atas:
  - Mengelola produk & stok.
  - Melakukan transaksi / bertindak sebagai kasir.
  - Mengirim invoice ke pembeli.
  - Melihat laporan penjualan.

> Catatan: multi-kasir / multi-role dan multi-toko **tidak** termasuk scope v1.

## 3. Tech Stack (PERN)

| Layer        | Teknologi                                                            |
|--------------|----------------------------------------------------------------------|
| Database     | **PostgreSQL** — produk, stok, transaksi, invoice                    |
| Backend API  | **Node.js + Express** — REST API, auth, integrasi WAHA & render      |
| Frontend     | **React (Vite) + vite-plugin-pwa** — PWA mobile-first, installable   |
| WhatsApp     | **WAHA** (self-hosted) — kirim image invoice + text + link digital   |
| Invoice Render | **Puppeteer** — render HTML invoice → PNG / PDF                    |
| Thermal Print | **@media print + WebUSB** — dari client React (tanpa install driver) |

### Mengapa stack ini
- **Vite + React + vite-plugin-pwa** adalah standar PWA React paling direkomendasikan: build cepat, service worker & manifest auto-generate (Workbox), bundle ringan → cocok untuk jaringan 4G/3G warung, dan mendukung offline caching.
- **PERN** familiar, mudah di-deploy, dan cukup untuk skala 1 toko.
- **WAHA** self-hosted gratis untuk kirim WhatsApp tanpa izin Meta resmi.
- **Puppeteer** menghasilkan image/PDF invoice yang konsisten dari template HTML yang sama dengan tampilan link digital.

## 4. Fitur Utama

### 4.1 Manajemen Produk & Stok
- CRUD produk: nama, SKU, kategori, harga jual, harga beli, satuan, stok awal.
- Pantau stok secara real-time.
- Alert otomatis saat stok menipis dan saat habis.
- Riwayat perubahan stok (restock / adjustment manual) lengkap dengan waktu & jumlah.
- Import produk massal via **CSV** untuk onboarding cepat.

### 4.2 Transaksi / Kasir
- Cart: cari atau scan produk, set quantity, diskon per item.
- Perhitungan total otomatis.
- Simpan transaksi → sistem generate invoice secara otomatis.

### 4.3 Pembayaran
- **Cash**: input uang pembayaran, sistem menghitung kembalian.
- **QRIS statis**: tampilkan QR statis milik pemilik, konfirmasi pembayaran secara manual oleh kasir.

### 4.4 Invoice
- Berisi: nomor invoice, tanggal, daftar item, total, metode pembayaran.
- **Print thermal**: template 58mm / 80mm via browser print / WebUSB.
- **Link digital**: URL publik `/i/{id}` yang bisa dibuka di HP pembeli.
- **Share WhatsApp** (via WAHA): auto kirim ke nomor pembeli berupa **image invoice + text ringkas + link digital**.
- **Download** invoice sebagai **PNG** dan **PDF** dari halaman link digital.

### 4.5 Laporan Ringan
- Penjualan harian, per produk, serta breakdown cash vs QRIS.
- Export laporan harian.

## 5. User Flow (Kasir)

1. Buka Qlosir (PWA) di HP → login (PIN).
2. Tap produk / scan → isi quantity → masuk ke cart.
3. Pilih metode bayar:
   - **Cash**: input uang → lihat kembalian.
   - **QRIS**: tampil QR statis → tunggu konfirmasi manual.
4. Transaksi selesai → invoice muncul.
5. **Cetak thermal** langsung, ATAU input nomor WA pembeli → sistem kirim image + text + link digital via WAHA.

## 6. Arsitektur (High-Level)

```
┌─────────────────────────┐
│  React PWA (Vite)       │  Mobile-first UI, cart, print, offline cache
│  - vite-plugin-pwa      │
└───────────┬─────────────┘
            │ HTTPS REST
┌───────────▼─────────────┐
│  Express (Node.js)      │  Auth, transaksi, stok, invoice API
│  - API routes           │
│  - WAHA client          │──► WAHA (self-hosted) ──► WhatsApp pembeli
│  - Render service       │──► Puppeteer ──► PNG / PDF
└───────────┬─────────────┘
            │ SQL
┌───────────▼─────────────┐
│  PostgreSQL             │  produk, stok, transaksi, invoice
└─────────────────────────┘
```

- **Thermal print** dilakukan di sisi client (React) via `@media print` + WebUSB — tidak butuh backend.
- **Link digital** di-serve sebagai halaman publik statis/SSR-light dari Express.
- **Puppeteer** dijalankan sebagai service terpisah/route untuk generate image & PDF agar tidak memblock request API utama.

## 7. Non-Functional Requirements

- Load cepat di jaringan 4G/3G warung (bundle ringan, precache app shell).
- **Offline-tolerant (recommended)**: cache daftar produk & stok di client, sinkronisasi transaksi saat kembali online.
- Auth simpel (PIN) untuk 1 user.
- UI dioptimalkan untuk layar HP (thumb-friendly, kontras tinggi, tombol besar).

## 8. Out of Scope (v1)

- Multi-toko & multi-kasir dengan role berbeda.
- QRIS dinamis / settlement & callback otomatis dari PSP.
- Fitur refund / retur.
- Integrasi pajak & akuntansi.

## 9. Success Metrics

- Transaksi selesai (dari tap pertama sampai invoice) **< 15 detik**.
- **≥ 90%** invoice WhatsApp terkirim tanpa error.
- Stok tercatat akurat (selisih < 1% vs fisik).
- PWA dapat di-install dan dibuka kembali dalam **< 3 detik** saat offline/dari homescreen.
